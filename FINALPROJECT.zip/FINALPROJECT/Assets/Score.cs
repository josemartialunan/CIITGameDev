﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Score : MonoBehaviour {

	public int currentScore;
	public void Increase() {
		currentScore++;

		if (currentScore == 11){
			SceneManager.LoadScene("LAVA");
		}
		if (currentScore == 31){
			SceneManager.LoadScene("JUNGLE");
		}
		if (currentScore == 51){
			SceneManager.LoadScene("RAINBOW");
		}

		Text textLabel = gameObject.GetComponent<Text> ();
		textLabel.text = "Score: " + currentScore;
	}

	// Use this for initialization
	void Start () {
		DontDestroyOnLoad(transform.root.gameObject);
	}
		
	// Update is called once per frame
	void Update () {
		
	}
}
