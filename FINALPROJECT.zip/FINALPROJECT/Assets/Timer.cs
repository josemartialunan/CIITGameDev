﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Timer : MonoBehaviour {

	float timer = 60;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		timer = timer - 1f * Time.deltaTime;
		if (timer <= 0) {
			Debug.Log ("Zero!");
			Text textLabel = gameObject.GetComponent<Text> ();
			textLabel.text = "Timer: " + timer;
			timer = 60;
		}
	}
}
