﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TheBoss : MonoBehaviour {

	public int hitAmount_Max = 20;
	private int hitAmount_Cur;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	void OnTriggerEnter2D (Collider2D col){
		if (col.tag == "player") {
			Debug.Log ("HitTheBoss!");
			Destroy (col.gameObject);
			Destroy (gameObject);
			Application.Quit ();
		}
		if (col.tag == "bullet") {
			Debug.Log ("FinalTouch!");
			Destroy (gameObject);
			Application.Quit ();
		}
	}
}
