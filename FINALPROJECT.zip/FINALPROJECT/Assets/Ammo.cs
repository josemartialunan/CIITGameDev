﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Ammo : MonoBehaviour {

	public int currentAmmo;
	public void Decrease(){
		currentAmmo--;
		Text textLabel = gameObject.GetComponent<Text> ();
		textLabel.text = "Ammo: " + currentAmmo;
	}
	public void Increase(){
		currentAmmo++;
		Text textLabel = gameObject.GetComponent<Text> ();
		textLabel.text = "Ammo: " + currentAmmo;
	}
	// Use this for initialization
	void Start () {
		DontDestroyOnLoad(transform.root.gameObject);
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
