﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SlowMoving : MonoBehaviour {

	public int hit = 2;
	// Use this for initialization

	public void Damage(int damage){
		hit -= damage;
		if (hit <= 0) {
			Destroy (gameObject);
		}
	}

	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	void OnTriggerEnter2D (Collider2D col) {
		if (col.tag == "player") {
			Debug.Log ("HitPlayer!");
			Destroy (col.gameObject);
			Destroy (gameObject);
		}
	}
}
