﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI
;

public class Lives : MonoBehaviour {

	public float lives;
	public void DecreaseLives(){
		lives--;
		Text textLabel = gameObject.GetComponent<Text> ();
		textLabel.text = "Lives: " + lives;

		if (lives <= 4) {
			Application.LoadLevel(0);
		}
	}

	public void IncreaseLives(){
		lives++;
		Text textLabel = gameObject.GetComponent<Text> ();
		textLabel.text = "Lives: " + lives;
		}

	// Use this for initialization
	void Start () {
		DontDestroyOnLoad(transform.root.gameObject);
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
