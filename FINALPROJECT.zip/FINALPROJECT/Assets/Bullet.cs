﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet : MonoBehaviour {

	public Object explosionPrefab;
	 
	// Use this for initialization

	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		transform.Translate (Vector2.right * 0.1f);
	}

	void OnTriggerEnter2D (Collider2D col){
		if (col.tag == "enemy") {
			Debug.Log ("Hit!");
			Destroy (col.gameObject);
			Destroy (gameObject);
			GameObject.Find ("Score").GetComponent<Score> ().Increase ();
			GameObject explosionGameObject = Instantiate (explosionPrefab) as GameObject;
			Explosion explosion = explosionGameObject.GetComponent<Explosion> ();
			explosion.transform.position = new Vector2 (transform.position.x + 5, transform.position.y);
			gameObject.GetComponent<Explosion>();
		}
		if (col.tag == "enemy2") {
			Debug.Log ("HitBullet!");
			GameObject.Find ("SlowMoving").GetComponent<SlowMoving> ().Damage (2);
		}
	}
}
