﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour {

	public Rigidbody2D rb;
	public float movespeed;
	public float jumpForce = 100;
	public Object bulletPrefab;

	// Use this for initialization
	void Start () {
		rb = GetComponent<Rigidbody2D>();
	}
	
	// Update is called once per frame
	void Update () {
		if (Input.GetKey(KeyCode.LeftArrow)){
			rb.velocity = new Vector2(-movespeed, rb.velocity.y);
		}
		if (Input.GetKey(KeyCode.RightArrow)){
			rb.velocity = new Vector2(movespeed, rb.velocity.y);
		}
		if ( Input.GetKeyDown(KeyCode.UpArrow) ) {
			rb.AddForce(Vector2.up * jumpForce);
		}
		if (Input.GetKeyDown (KeyCode.Space)) {
				GameObject bulletGameObject = Instantiate (bulletPrefab) as GameObject;
				Bullet bullet = bulletGameObject.GetComponent<Bullet> ();
				bullet.transform.position = new Vector2 (transform.position.x + 5, transform.position.y);
				GameObject.Find ("Ammo").GetComponent<Ammo> ().Decrease ();
		}
	}
}
